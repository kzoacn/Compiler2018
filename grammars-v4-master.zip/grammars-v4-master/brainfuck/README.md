# Brainfuck Grammar

A simple ANTLR4 grammar for [Brainfuck](https://en.wikipedia.org/wiki/Brainfuck)
