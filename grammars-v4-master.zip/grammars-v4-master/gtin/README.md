# GTIN Grammar

An ANTLR4 grammar for [GTIN codes](https://en.wikipedia.org/wiki/Global_Trade_Item_Number).

