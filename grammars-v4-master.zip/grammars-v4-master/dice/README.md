# Dice Notation Grammar

## Source

Created for the [Dice Notation Tools for Java](https://github.com/Bernardo-MG/dice-notation-java/blob/master/LICENSE).

## Summary

The dice notation is widely used by tabletop game, mainly RPGs.

It defines a set of dice to be used for generating random values through a description such as 2d6+3.
