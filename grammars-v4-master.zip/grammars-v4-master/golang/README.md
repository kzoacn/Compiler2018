# Golang Grammar

An ANTRL4 grammar for Golang based on [The Go Programming Language Specification](https://golang.org/ref/spec).
