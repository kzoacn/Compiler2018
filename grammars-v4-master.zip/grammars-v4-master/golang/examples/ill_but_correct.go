package main;

import "fmt"

func main() { ;
	ch <- 1 }
