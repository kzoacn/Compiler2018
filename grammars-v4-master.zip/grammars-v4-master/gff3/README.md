# GFF3 Grammar

An ANTLR4 grammar for [gff3](http://gmod.org/wiki/GFF3) (Generic Feature Format 3) files.

You can download appropriate example files here [ftp://ftp.ncbi.nih.gov/genomes/](ftp://ftp.ncbi.nih.gov/genomes/).
