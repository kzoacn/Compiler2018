# FOL Grammar

An ANTLR4 grammar for [First order logic](https://en.wikipedia.org/wiki/First-order_logic) files.