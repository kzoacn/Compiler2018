# INF Grammar

An ANTLR4 grammar for [INF](https://en.wikipedia.org/wiki/INF_file) files.
