ANTLR v4 grammar for the FlatBuffers schema language: https://google.github.io/flatbuffers/flatbuffers_grammar.html
