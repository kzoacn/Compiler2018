ANTLR v4 grammar for the Cap'n Proto schema language: https://capnproto.org/language.html
