nasm -felf64 $1.nasm
gcc -static $1.o


