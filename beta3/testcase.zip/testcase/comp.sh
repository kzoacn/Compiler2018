nasm -felf64 $1.nasm
gcc $1.o


