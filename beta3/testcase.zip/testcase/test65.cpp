#include<bits/stdc++.h>
using namespace std;
int main(){
    int len=100;
    int i=0;
    string s="";
    for(i=0;i<len;i++)
        s=s+"0";
    cout<<s<<endl;
    for(i=0;i<len;i++)
        s=s+"0";
    cout<<s<<endl; 
    return 0;
}
