#include <stdio.h>

int main(){
  char a =1;
  char b =2;
  a = b + a;
  a *= 2;
  printf("%d\n",a);
  return a;
}







